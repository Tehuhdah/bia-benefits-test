-- AlterTable
ALTER TABLE "Deal" ADD COLUMN     "Description" TEXT;
