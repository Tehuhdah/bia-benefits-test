-- AlterTable
ALTER TABLE "Business" ADD COLUMN     "businessId" TEXT;
