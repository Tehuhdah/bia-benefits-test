-- AlterTable
ALTER TABLE "BIA" ALTER COLUMN "active" SET DEFAULT true;
