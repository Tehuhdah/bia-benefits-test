-- DropIndex
DROP INDEX "User_name_key";
